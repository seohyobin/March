import React from 'react';

const IntroMainComponent = () => {
    return (
        <div className='sub-page intro'>
            <h1>인트로</h1>
        </div>
    );
};

export default IntroMainComponent;