import React from 'react';


export default function SignUpComponent() {
    return (
        <main id='signUp'>
            <h1>SignUpComponent</h1>
        </main>
    );
};
