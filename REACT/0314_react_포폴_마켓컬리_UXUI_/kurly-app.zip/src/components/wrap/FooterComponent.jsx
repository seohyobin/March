import React from 'react';

export default function FooterComponent() {
    return (
        <footer id='footer'>
            <h1>FooterComponent</h1>
        </footer>
    );
};